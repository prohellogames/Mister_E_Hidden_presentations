﻿# char
define e = Character('Евсин', color="#327432")
define mc = Character('Я', color="#354128")
define m = Character('', color="#000000")

# music
define mus1 = "ost/Waking Up in the Morning.mp3"
define mus2 = "ost/Town, Flow of Time, People.mp3"
define mus3 = "ost/Town, Flow of Time, People.mp3"
define mus4 = "ost/Town, Flow of Time, People.mp3"

# sound
define sfx1 = "sfx/ring.mp3"
# bg
image college = "bgs/college.png"
image market = "bgs/market.png"
image nighth = "bgs/homenight.png"
image dayh = "bgs/homeday.png"
image classc = "bgs/class.png"
# Evsin sprite sheet
image evs_idle = Transform("Char/Evsin.png", crop=(96, 1, 170, 400))
image evs_look = Transform("Char/Evsin.png", crop=(319, 1, 230, 400))
image evs_bhnd = Transform("Char/Evsin.png", crop=(777, 1, 161, 400))
image evs_think = Transform("Char/Evsin.png", crop=(86, 518, 153, 400))

# other
image GG = "Char/gg.png"

label start:
    scene black
    window hide
    show text "День 1" at truecenter with Dissolve(1.5)
    pause 3
    window show
    hide text with Dissolve(1.5)
    stop music fadeout 1.5
    mc "Доброе утро новый день."
    m "Я открыл глаза"
    show dayh with Fade(0.01, 0.0, 3.5, color="#000000")
    play music mus2
    m "Я посмотрел на часы, и увидел что уже 6 утра."
    mc "Наконец то я проснулся вовремя."
    m "Раньше я попросту просыпал, что даже будильник не слышал, из-за чего опаздывал на пары."
    m "Но сегодня я проснулся вовремя, и был рад этому, ведь сегодня мне нужно было прийти к 8 утра."
    mc "Как же бесят утренние пары, почему мы не можем приходить к 9, чтобы ещё часик поспать."
    mc "Я бы хотел спать до конца дня."
    m "После утренних дел я собрался и поехал в колледж."
    show college with fade
    stop music fadeout 1.5
    play music mus1 fadein 2.0
    m "Наконец то я приехал, даже немного раньше."
    m "Новый курс только начался, а я уже устал от учёбы."
    m "Но я всё равно шёл в колледж, ведь мне нужно было сдать экзамены, а я не хотел бы их завалить."
    m "Первой парой стояло программирование, что немного меня радовало, ведь я люблю этот предмет."
    m "До урока оставалось ещё 10 минут, и я решил пойти в магазин чтобы купить себе что-нибудь попить."
    show market with Dissolve(0.5)
    m "Я зашёл в магазин, который находился недалеко от колледжа."
    m "Я решил взять себе какую нибудь газировку и в итоге остановился на банке колы."
    m "Я взял банку и пошёл к кассе."
    m "Я оплатил покупку и выпил колу, потом пошёл обратно в колледж, ведь до урока оставалось всего 3 минуты."
    hide market with Dissolve(0.5)
    #show college with Dissolve(0.5)
    m "Я зашёл в колледж и пошёл в аудиторию."
    show classc with Dissolve(0.5)
    m "Я зашёл и увидел как всегда обычную картину на первых занятиях, были всего пару человек в аудитории и учитель."
    m "Я сел на своё место и начал ждать начала урока играя в subway surfers."
    play sound sfx1
    m "Наконец то прозванивает звонок и урок начался."
    m "Учителя ктати звали Евсин Денис Дмитриевич, и он был выпускником этого колледжа."
    show evs_think at Transform(xalign=0.5, yalign=1.0, zoom=2) with Dissolve(0.5)
    e 'Доброе утро всем, сегодня мы будем писать лекцию "режимы работы процессора".'
    m "Я достал тетрадь и начал писать конспект."
    m "Я писал конспект, но в какой-то момент я понял что хочу спать, ведь я всё таки не очень хорошо выспался."
    mc "*зевок*"
    hide dayh
    hide college
    show black
    hide evs_think with Dissolve(0.5)
    hide classc with Dissolve(0.5)
    m "Я начал клевать носом, и в какой-то момент уснул..."
    m "..."
    play sound sfx1
    show classc with Dissolve(0.5)
    m "Я проснулся и понял что я проспал весь урок."
    m "Хорошо, что я вспомнил что у нас есть общая группа с учителем, куда он скидывал презентации."
    show evs_idle at Transform(xalign=0.5, yalign=1.0, zoom=2) with Dissolve(0.5)
    mc "Здравствуйте, могли бы вы скинуть презентации по программированию?"
    e "Здравствуйте, конечно скину, только подождите немного."
    mc "Когда вы скинете презентации?"
    e "Я скину их в течении дня в группу, не переживайте."
    mc "Хорошо, спасибо."
    m "Я вышел из кабинета и вышел на улицу, чтобы проветриться."
    show college with Dissolve(0.5)
    hide evs_idle with Dissolve(0.5)
    m 'После урока было ещё три пары.'

    m "После урока я пошёл домой, ведь мне нужно было отдохнуть и подготовиться к следующему дню."
    show nighth with fade
    m "Я наконец таки приехал домой"
    m "Я зашёл в дом и пошёл в свою комнату, чтобы отдохнуть."
    mc "Наконец то отдых"
    m "Когда я лёг на кровать, я понял что забыл записать сегодняшний конспект по программированию."
    mc "Точно, конспект."
    m "Я решил переписать конспект по программированию, который не записал на уроке."
    m "Я открыл чат с учителем и увидел что он не скинул презентации в группу."
    m "Я решил написать ему в личные сообщения, чтобы он скинул мне презентации."
    m "Я написал ему и ждал ответа."
    m "Через некоторое время он только прочитал, но ничего не скинул."
    m "Я даже не подозревал что ето зайдёт так далеко..."
    window hide
    hide nighth
    show GG at Transform(xalign=0.5, yalign=0.0, zoom=6)
    pause 4
    return